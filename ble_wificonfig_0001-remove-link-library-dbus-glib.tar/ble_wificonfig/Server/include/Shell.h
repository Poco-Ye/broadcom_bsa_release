#ifndef __SOFTAP_SHELL_H__
#define __SOFTAP_SHELL_H__

#include <stdio.h>
#include <string.h>

bool exec(const char* cmd, char* result);

#endif //__SOFTAP_SHELL_H__
