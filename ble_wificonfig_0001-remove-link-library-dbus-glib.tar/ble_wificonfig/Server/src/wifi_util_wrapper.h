#ifndef _WIFI_UTIL_WRAPPER_H__
#define _WIFI_UTIL_WRAPPER_H_
#ifdef __cplusplus
extern "C" {
#endif
/*return json c string*/
extern char *get_wifi_list();
extern char *get_device_context();
#ifdef __cplusplus
};
#endif
#endif
