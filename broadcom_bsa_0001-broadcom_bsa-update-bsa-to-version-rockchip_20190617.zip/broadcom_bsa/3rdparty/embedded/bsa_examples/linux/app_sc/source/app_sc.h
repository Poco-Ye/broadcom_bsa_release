#ifndef __APP_SC_H__
#define __APP_SC_H__

#ifdef  __cplusplus
extern "C"
{
#endif


#ifdef  __cplusplus
}
#endif

#endif /* __APP_SC_H__ */
